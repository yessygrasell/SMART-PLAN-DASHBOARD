// function to print object into console
function printObject(value) {
  server.console.log(JSON.stringify(value, null, '  '))
}