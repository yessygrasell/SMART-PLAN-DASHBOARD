// *****************************************************************************
// Script: PID voltage controller
// Trigger: Periodically 1000ms
// This script is designed to change the amperage with a PID controller and 
// regulate the voltage
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    setpoint: 'voltageSetpoint',
    voltage: 'voltage',
    amperage: 'amperage',
    resistance: 'resistance',
    kp: 'kp',
    ki: 'ki',
    kd: 'kd'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_PIDcontroller_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    if (stored !== null) {
        let dt = (current.timestamp.valueOf() - stored.timestamp.valueOf()) / 1000;
        let max = current.setpoint * 2;
        let min = -max;

        let error = current.setpoint - current.voltage;
        let integral = checkRange((stored.integral + error * dt * current.ki), min, max);
        let diff = (error - stored.error) / dt;
        let amperageValue = checkRange((error * current.kp + integral + diff * current.kd), min, max);
        current.amperage = amperageValue;
        objects.amperage.setValue(amperageValue);

        current.error = error;
        current.integral = integral;
    }
    //makeData
    let voltageValue = current.amperage * current.resistance;
    objects.voltage.setValue(voltageValue);

    storeValues(current, stored);
}

function checkRange(value, min, max) {
    if (value > max) {
        return max;
    }
    if (value < min) {
        return min;
    }
    return value;
}

function storeValues(current, stored) {
    let needStore = (current !== stored);
    if (needStore) {
        server.storage.set(storageKeys.snapshot, current);
    }
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        timestamp: new Date(),
        voltage: tryGetNumber(objects.voltage),
        amperage: tryGetNumber(objects.amperage),
        setpoint: tryGetNumber(objects.setpoint),
        resistance: tryGetNumber(objects.resistance),
        kp: tryGetNumber(objects.kp),
        ki: tryGetNumber(objects.ki),
        kd: tryGetNumber(objects.kd),
        error: 0,
        integral: 0
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        voltage: dev.item(targetNames.voltage),
        amperage: dev.item(targetNames.amperage),
        setpoint: dev.item(targetNames.setpoint),
        resistance: dev.item(targetNames.resistance),
        kp: dev.item(targetNames.kp),
        ki: dev.item(targetNames.ki),
        kd: dev.item(targetNames.kd),
    }
    return result;
}