// *****************************************************************************
// Script: Dynamic set point change
// Trigger: Periodically 1000ms 
// This script is designed to dynamically change the parameter thresholds when 
// the set point changes
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    signal: 'signal1',
    setpoint: 'setpoint',
    delay: 'setpointDelay'
}

const shifts = {
    hi: "hiShift",
    hihi: "hihiShift",
    lo: "loShift",
    lolo: "loloShift"
}

const timeDelay = 5;// in seconds

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_snapshot`,
    changes: `${targetNames.source}_${targetNames.device}_changes`
}

// Entry point, don't delete!
function main() {
    let objects = getObjects();

    executeCommand(objects);

    let currentValues = getValues(objects);

    let storedValues = getStoredValues();

    if (isValuesChanged(storedValues, currentValues)) {
        storeCommand(currentValues);
        server.storage.set(storageKeys.snapshot, currentValues);
    }
}

function setValues(objects, prevChanges) {
    if (prevChanges === null) {
        return;
    }

    let values = prevChanges.Snapshot;
    let config =
    {
        "config": {
            "hihi": values.setpoint + values.hihiShift,
            "hi": values.setpoint + values.hiShift,
            "lo": values.setpoint - values.loShift,
            "lolo": values.setpoint - values.loloShift
        }
    }
    objects.signal.setConfig(config);
    server.storage.delete(storageKeys.changes);
}

function executeCommand(objects) {
    let prevChanges = server.storage.get(storageKeys.changes);
    if (isTimeElapsed(prevChanges)) {
        setValues(objects, prevChanges);
    }
}

function isTimeElapsed(prevChanges) {
    if (prevChanges === null) {
        return false;
    }
    let delay = Number(prevChanges.Snapshot.delay);
    let ts = new Date(prevChanges.Timestamp);
    let tsn = new Date();
    let diff = tsn.getTime() - ts.getTime();
    if (diff >= delay * 1000) {
        return true;
    }
    return false;
}

function storeCommand(values) {
    let command = {
        Timestamp: new Date().toUTCString(),
        Snapshot: values
    }
    server.storage.set(storageKeys.changes, command);
}

function isValuesChanged(prev, cur) {
    if (!prev) {
        return true;
    }
    if ((prev.setpoint != cur.setpoint) ||
        (prev.hihi != cur.hihi) ||
        (prev.hi != cur.hi) ||
        (prev.lo != cur.lo) ||
        (prev.lolo != cur.lolo) ||
        (prev.hihiShift != cur.hihiShift) ||
        (prev.hiShift != cur.hiShift) ||
        (prev.loShift != cur.loShift) ||
        (prev.loloShift != cur.loloShift) ||
        (prev.delay != cur.delay)) {
        return true;
    }
    return false;
}

function getStoredValues() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let itemConfig = objects.signal.getConfig().config;
    let currentValue = 0;
    let signalValue = objects.signal.getValue();
    if (signalValue !== null) {
        currentValue = Number(signalValue.null);
    }

    let result = {
        current: currentValue,
        setpoint: Number(objects.setpoint.getValue().value),
        delay: Number(objects.delay.getValue().value),
        hihi: Number(itemConfig.hihi),
        hi: Number(itemConfig.hi),
        lo: Number(itemConfig.lo),
        lolo: Number(itemConfig.lolo),
        hihiShift: Number(objects.hihiShift.getValue().value),
        hiShift: Number(objects.hiShift.getValue().value),
        loShift: Number(objects.loShift.getValue().value),
        loloShift: Number(objects.loloShift.getValue().value)
    }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        signal: dev.item(targetNames.signal),
        setpoint: dev.item(targetNames.setpoint),
        delay: dev.item(targetNames.delay),
        hihiShift: dev.item(shifts.hihi),
        hiShift: dev.item(shifts.hi),
        loShift: dev.item(shifts.lo),
        loloShift: dev.item(shifts.lolo)
    }
    return result;
}