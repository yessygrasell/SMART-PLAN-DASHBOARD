// *****************************************************************************
// Script: Sine generator
// Trigger: Periodically 1000ms
// This script is designed to generate sinusoidal signals
// *****************************************************************************


const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    signals: {
        signal1: 'signal1',
        signal2: 'signal2',
        signal3: 'signal3',
        signal4: 'signal4'
    }
}

const frequencies = {
    signal1: 5,
    signal2: 5,
    signal3: 5,
    signal4: 5
}

const amplitudes = {
    signal1: 100,
    signal2: 200,
    signal3: 300,
    signal4: 400
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    setValues(objects);
}

function setValues(objects) {
    let t = Math.round(Date.now() / 1000);
    // signal1
    let value = makeValue(t, amplitudes.signal1, frequencies.signal1);
    objects.signal1.setValue(value);
    // signal2
    value = makeValue(t, amplitudes.signal2, frequencies.signal2);
    objects.signal2.setValue(value);
    // signal3
    value = makeValue(t, amplitudes.signal3, frequencies.signal3);
    objects.signal3.setValue(value);
    // signal4
    value = makeValue(t, amplitudes.signal4, frequencies.signal4);
    objects.signal4.setValue(value);
}

function makeValue(t, amplitude, frequency) {
    let f = frequency * Math.PI / 180;
    return amplitude * Math.sin(f * t);
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        signal1: dev.item(targetNames.signals.signal1),
        signal2: dev.item(targetNames.signals.signal2),
        signal3: dev.item(targetNames.signals.signal3),
        signal4: dev.item(targetNames.signals.signal4)
    }
    return result;
}