// *****************************************************************************
// Script: Init
// Trigger: Periodically 1000ms 
// The script is used for set validate status for all command parameters
// *****************************************************************************

function main() {
  let objects = server.objects('scripts')
  
  objects.forEach(o => {
    o.items().forEach(i => {
        if (i.alias == "Connect") {
          let connect = (Number(i.getValue()?.value) == 1)
          server.console.log(connect)
          if (!connect) {  i.setValue(1, {quality: true}) }
        }
        else { setValid(i) }
    })
  })
}

function setValid(i, value = 0) {
  let quality = (i.getValue()?.quality == true)
  if (!quality) {
      i.setValue(value, {quality: true})
  }
}
