// *****************************************************************************
// Script: 	Starting a sequence of actions
// Trigger: Periodically 1000ms
// This script is designed to demonstrate the ability to run a sequence of 
// actions in atomic(when the warning / alarm level is reached) and 
// manual(when the discrete is changed) modes. 
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    discrete: 'bit1',
    floatIn: 'signal1',
    floatOut: 'float1'
}

const delay = 10;// delay before setting the float parameter, seconds
const floatWarning = 1;// value to which the float parameter is set on warning
const floatAlarm = 10;// value to which the float parameter is set on alarm

const stateValues = {
    hihi: 2,
    hi: 1,
    normal: 0,
    lo: -1,
    lolo: -2
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_actionsSequence_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    let saveStored = false;

    //process previous command
    if (stored !== null) {
        if (stored.command !== null) {
            let prevTs = stored.command.timestamp.valueOf();
            let curTs = new Date().valueOf();
            if ((curTs - prevTs) >= (delay * 1000)) {
                objects.floatOut.setValue(stored.command.value);
                current.command = null;
                saveStored = true;
            }
            else {
                current.command = stored.command;
            }
        }
    }

    //process manual
    // 0 -> 1
    if (stored !== null && stored.snapshot.discrete === 0 && current.discrete === 1) {
        current.command = {
            timestamp: new Date(),
            value: floatAlarm
        }
        saveStored = true;
    }

    // reset discrete
    if (stored !== null && stored.snapshot.discrete === 1 && current.discrete === 1) {
        objects.discrete.setValue(0);
        current.discrete = 0;
    }

    //process automated
    let config = objects.floatIn.getConfig().config;
    current.floatState = getFloatState(current.floatIn, config.hihi, config.hi, config.lo, config.lolo);

    if (stored !== null) {
        // case hi warning
        if (current.floatState == 1 && stored.floatState !== 1) {
            objects.floatOut.setValue(floatWarning);
        }
        // case hihi alarm
        if (current.floatState == 2 && stored.floatState !== 2) {
            objects.floatOut.setValue(floatAlarm);
        }
    }

    storeValues(current, stored, saveStored);
}

function storeValues(current, stored, saveStored) {
    if ((stored === null) ||
        (current.floatState !== stored.snapshot.floatState) ||
        (current.discrete !== stored.snapshot.discrete) || saveStored) {
        let storeValue = {
            snapshot: {
                discrete: current.discrete,
                floatState: current.floatState
            },
            command: current.command
        }
        server.storage.set(storageKeys.snapshot, storeValue);
    }

}

function getFloatState(value, hihi, hi, lo, lolo) {
    let result = stateValues.normal;
    // hihi
    if (value >= hihi) {
        result = stateValues.hihi;
    }
    // hi
    if (value >= hi && value < hihi) {
        result = stateValues.hi;
    }
    // lo
    if (value <= lo && value > lolo) {
        result = stateValues.lo;
    }
    // lolo
    if (value <= lolo) {
        result = stateValues.lolo;
    }
    return result;
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        discrete: tryGetNumber(objects.discrete),
        floatIn: tryGetNumber(objects.floatIn)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        discrete: dev.item(targetNames.discrete),
        floatIn: dev.item(targetNames.floatIn),
        floatOut: dev.item(targetNames.floatOut)
    }
    return result;
}