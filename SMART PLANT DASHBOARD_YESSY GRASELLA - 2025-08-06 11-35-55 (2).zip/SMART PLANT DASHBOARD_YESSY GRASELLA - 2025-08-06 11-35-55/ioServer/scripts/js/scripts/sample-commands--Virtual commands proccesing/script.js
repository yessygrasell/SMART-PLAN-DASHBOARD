// *****************************************************************************
// Script: Virtual commands proccesing
// Trigger: Periodically: 1000ms
// The script evaluates users commands for 'scripts' virtual devices
// *****************************************************************************
function main() {
  let commands = server.getCommands()
  commands.forEach(cmd => {
    JSON.stringify(cmd, null, '  ')
    let o = server.object('scripts', cmd.objectAlias)
    let i = o.item(cmd.itemAlias)
    i.setValue(cmd.value)
  })
}