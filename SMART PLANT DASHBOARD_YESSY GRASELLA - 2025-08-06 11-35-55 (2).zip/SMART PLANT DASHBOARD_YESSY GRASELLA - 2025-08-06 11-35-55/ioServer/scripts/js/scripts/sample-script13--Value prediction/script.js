// *****************************************************************************
// Script: Value prediction
// Trigger: Periodically 1000ms
// This script is designed to calculate the time of reaching the set value and 
// the possible value at the end of the calculation interval
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    discreteIn: 'com3',
    floatIn: 'valueToPredict',
    targetValue: 'targetValue',
    calcInterval: 'calculationInterval',
    reachTime: 'reachTime',
    reachValue: 'reachValue'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_prediction_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    let command = null;

    if (stored !== null) {
        command = stored.command;
        // discreteIn 1 -> 1
        if (stored.prevDiscreteIn === 1 && current.discreteIn === 1) {
            objects.discreteIn.setValue(0);
        }

        // discreteIn 0 -> 1
        if (stored.prevDiscreteIn === 0 && current.discreteIn === 1) {
            current.floatIn = 0;
            objects.floatIn.setValue(current.floatIn);
            let from = new Date();
            let to = new Date(from.valueOf() + current.calcInterval * 1000);
            command = {
                tsFrom: from,
                tsTo: to
            }
        }
        // make data
        else if (command !== null) {
            if (!isTimeElapsed(current.timestamp, command.tsFrom, command.tsTo)) {
                let floatInValue = current.floatIn + 3;
                objects.floatIn.setValue(floatInValue);
                current.floatIn = floatInValue;
            }
            else {
                command = null;
            }
        }
        // make calculations
        if (isDifferent(current, stored)) {
            let interval = (current.timestamp.valueOf() - stored.prevTimestamp.valueOf()) / 1000;
            let speed = (current.floatIn - stored.prevFloatIn) / interval;

            // reach time
            let diff = current.targetValue - current.floatIn;
            let reachTime = Math.round((diff > 0) ? diff / speed : 0);
            objects.reachTime.setValue(reachTime);

            // reach value
            let predictedValue = Math.round(speed * current.calcInterval);
            objects.reachValue.setValue(predictedValue);
        }
    }
    storeValues(current, stored, command);
}

function isDifferent(current, stored) {
    if (current.floatIn !== stored.prevFloatIn) {
        return true;
    }
    return false;
}

function isTimeElapsed(current, from, to) {
    if (current >= from && current <= to) {
        return false;
    }
    return true;
}

function storeValues(current, stored, command) {
    let needStore = (stored === null ||
        current.discreteIn !== stored.prevDiscreteIn ||
        current.floatIn !== stored.prevFloatIn ||
        stored.command !== command);

    if (needStore) {
        let storeValue = {
            prevDiscreteIn: current.discreteIn,
            prevFloatIn: current.floatIn,
            prevTimestamp: current.timestamp,
            command: command
        }
        server.storage.set(storageKeys.snapshot, storeValue);
    }
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        discreteIn: tryGetNumber(objects.discreteIn),
        floatIn: tryGetNumber(objects.floatIn),
        timestamp: new Date(),
        targetValue: tryGetNumber(objects.targetValue),
        calcInterval: tryGetNumber(objects.calcInterval)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        discreteIn: dev.item(targetNames.discreteIn),
        floatIn: dev.item(targetNames.floatIn),
        targetValue: dev.item(targetNames.targetValue),
        calcInterval: dev.item(targetNames.calcInterval),
        reachTime: dev.item(targetNames.reachTime),
        reachValue: dev.item(targetNames.reachValue)
    }
    return result;
}