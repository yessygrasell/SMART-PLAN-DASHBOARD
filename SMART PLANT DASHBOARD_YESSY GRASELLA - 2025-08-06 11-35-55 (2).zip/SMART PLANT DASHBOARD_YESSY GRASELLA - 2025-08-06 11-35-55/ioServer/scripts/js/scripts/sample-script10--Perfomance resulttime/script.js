// *****************************************************************************
// Script: Perfomance result/time
// Trigger: Periodically 1000ms
// This script is designed to calculate performance 
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    com: 'com2',
    production: 'production2',
    perfomance: 'perfomance'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_perfomance_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    current = makeData(objects, current);

    let stored = getStored();

    if (stored !== null) {
        if (isDataDiffers(current, stored)) {
            let valueDiff = current.production - stored.production;
            let timeDiff = (current.timestamp.valueOf() - stored.timestamp.valueOf()) / 1000;
            let perfomanceValue = valueDiff / timeDiff;
            objects.perfomance.setValue(perfomanceValue);
            storeValues(current);
        }
    }
    else {
        storeValues(current);
    }
}

function storeValues(current) {
    let stored = {
        timestamp: current.timestamp,
        production: current.production
    }
    server.storage.set(storageKeys.snapshot, stored);
}

function isDataDiffers(current, stored) {
    if (current.production !== stored.production) {
        return true;
    }
    return false;
}

function makeData(objects, current) {
    if (current.com === 1) {
        let prodValue = current.production + getRndInteger(1, 5);
        objects.production.setValue(prodValue);
        current.production = prodValue;
    }
    return current;
}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        timestamp: new Date(),
        com: tryGetNumber(objects.com),
        production: tryGetNumber(objects.production)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    try {
        let itemValue = item.getValue();
        if (itemValue !== null) {
            if (isFinite(itemValue.value)) {
                result = Number(itemValue.value);
            }
        }
    }
    catch (err) { }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        com: dev.item(targetNames.com),
        production: dev.item(targetNames.production),
        perfomance: dev.item(targetNames.perfomance)
    }
    return result;
}