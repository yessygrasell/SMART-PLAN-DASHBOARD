// The script increment set 'Connect' parameter
// 'value-raw' for all 'scripts' devices
function main() {
  let itemName = 'value-raw'
	
  const objects = server.objects('scripts')
  let valueRaw = Math.abs(server.storage.get(itemName) ?? 0)
  server.storage.set(itemName, ++valueRaw % 300)
  
  objects.forEach(o => {
    let dev = server.object(o.sourceId, o.alias)
  
    // check if connect bad
    let connect = o.item('Connect')
    let connectValue = connect?.getValue()

    if (connectValue?.value != true || !connectValue?.quality)
        connect.setValue(true)

    //check that 'value-raw' parameter
    let i = o.item(itemName)
    let iConfig = i.getConfig() ?? false
    if (i) i.setValue(valueRaw)
  })
}
