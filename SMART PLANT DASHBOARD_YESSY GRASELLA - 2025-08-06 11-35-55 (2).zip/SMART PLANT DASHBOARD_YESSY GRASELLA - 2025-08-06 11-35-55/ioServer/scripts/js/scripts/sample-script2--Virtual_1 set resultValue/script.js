// *****************************************************************************
// Script: Virtual_1 set value
// Trigger: On data change - virtual_1.value-raw
// The script uses calibrate table and calculate value from valueRaw
// Uses 'getValueFromCalcTable' user function
// *****************************************************************************

function main() {
	let itemName = 'value-raw'
    let dev = server.object('scripts', 'virtual_1')
    let valueRaw = Number(dev.item(itemName).getValue().value)

    let value = calTable.getValueFromCalcTable(valueRaw)
    dev.item('value').setValue(value)

    //server.console.log(`resultValue: ${resultValue}`)
}
