// *****************************************************************************
// Script: Alarm of no operator action
// Trigger: Periodically 1000ms
// This script is designed for periodic notification of the absence of operator 
// action in case of warning / alarm signals
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    floatIn: 'ackFloat',
    discrete: 'ackBit',
    ackInterval: 'ackInterval'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_alarmAction_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    let command = null;

    if (stored !== null) {
        command = stored.command;
        if (current.discrete === 1 && stored.discrete === 1) {
            objects.discrete.setValue(0);
        }
        // unack 0 -> 1
        if (stored.unack === false && current.unack === true) {
            command = makeCommand(current.timestamp, current.ackInterval);
        }
        // unack 1 -> 0
        if (stored.unack === true && current.unack === false) {
            command = null;
        }
        // unack 1 -> 1
        if (stored.unack === true && current.unack === true) {
            if (command === null) {
                command = makeCommand(current.timestamp, current.ackInterval);
            }
        }

        // main process
        if (command !== null) {
            if (current.unack === true) {
                if (isTimeElapsed(current.timestamp, command.tsFrom, command.tsTo)) {
                    objects.discrete.setValue(1);
                    command = makeCommand(current.timestamp, current.ackInterval);
                }
            }
        }
    }

    storeValues(current, stored, command);
}

function makeCommand(current, interval) {
    let from = current;
    let to = new Date(from.valueOf() + interval * 1000);
    let result = {
        tsFrom: from,
        tsTo: to
    }
    return result;
}

function isTimeElapsed(current, from, to) {
    if (current >= from && current <= to) {
        return false;
    }
    return true;
}

function storeValues(current, stored, command) {

    let storeValue = {
        timestamp: current.timestamp,
        unack: current.unack,
        discrete: current.discrete,
        command: command
    }

    server.storage.set(storageKeys.snapshot, storeValue);

}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        timestamp: new Date(),
        unack: objects.floatIn.getValue().unack,
        discrete: tryGetNumber(objects.discrete),
        ackInterval: tryGetNumber(objects.ackInterval),
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        floatIn: dev.item(targetNames.floatIn),
        discrete: dev.item(targetNames.discrete),
        ackInterval: dev.item(targetNames.ackInterval)
    }
    return result;
}