// *****************************************************************************
// Script: Periodic shift summary record
// Trigger: Periodically 1000ms
// This script is designed to periodically save the counted data. Recording is done
// by setting the saveCounted to 1 and running the actions described in 
// "Counting the number of triggers". 
// *****************************************************************************

let targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    trigger: 'saveCounted'
}

const Interval = 60;// seconds

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_shiftSummary_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    if (isIntervalsDiff(objects, current, stored)) {
        stored = storeValues(current);
    }

    if (!isWithinInterval(current, stored)) {
        objects.trigger.setValue(1);
        storeValues(current);
    }
}

function isWithinInterval(current, stored) {
    if (current.timestamp >= stored.tsFrom && current.timestamp < stored.tsTo) {
        return true;
    }
    return false;
}

function storeValues(current) {
    let from = current.timestamp;
    let to = new Date(current.timestamp.valueOf() + current.interval * 1000);

    let stored = {
        interval: current.interval,
        tsFrom: from,
        tsTo: to
    }
    server.storage.set(storageKeys.snapshot, stored);
    return stored;
}

function isIntervalsDiff(objects, current, stored) {
    if ((stored === null) || current.interval !== stored.interval) {
        return true;
    }
    return false;
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let ts = new Date();
    let tsFrom
    let result = {
        interval: Interval,
        timestamp: new Date()
    }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        trigger: dev.item(targetNames.trigger)
    }
    return result;
}