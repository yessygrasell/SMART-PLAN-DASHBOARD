// *****************************************************************************
// Script: Operating time calculation
// Trigger: Periodically 1000ms
// The script allows you to calculate the operating time of the device
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    flag: 'Connect',
    time: 'operatingTime',
    repair: 'repair' // 1 -> in repair state, 0 -> in operating state
}

const storageKeys = {
    repair: `${targetNames.source}_${targetNames.device}_${targetNames.repair}_stored`
}

const dbFormat = {
    delimeter: 1,//this parameter is used to write to the database (1 - in seconds, 60 - in hours, etc.)
    units: 'seconds'
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let values = getValues(objects);

    let storedValues = getStored(values);

    processValues(objects, values, storedValues);
}

function processValues(objects, current, stored) {
    // operating state continues
    if ((current.repair !== 1) && (stored.repair !== 1)) {
        if (current.flag === 1) {
            increaseValue(objects.time, current.time);
        }
    }
    // switch to repair state
    else if ((current.repair === 1) && (current.repair !== stored.repair)) {
        makeRecordToDb(objects, current);
    }
    // switch to operating state
    else if ((current.repair === 0) && (stored.repair === 1)) {
        objects.time.setValue(0);
        if (current.flag === 1) {
            increaseValue(objects.time, 0);
        }
    }

    storeValues(current, stored);
}

function makeRecordToDb(objects, values) {
    let deviceConfig = objects.device.getConfig();
    let triggerConfig = objects.time.getConfig();

    let message = `${deviceConfig.alias} device in state of repair. Operating time ${values.time / dbFormat.delimeter} ${dbFormat.units}`;
    let record = {
        Timestamp: new Date().toISOString(),
        ItemId: triggerConfig.id,
        DeviceId: deviceConfig.id,
        DeviceName: deviceConfig.alias,
        ItemName: triggerConfig.alias,
        Value: values.repair,
        Type: 'I',
        Message: message,
        LoggingNode: ''
    }
    server.db.insert("Events", [record]);
}

function storeValues(current, stored) {
    if (current.repair !== stored.repair) {
        server.storage.set(storageKeys.repair, current.repair);
    }
}

function increaseValue(item, value) {
    value++;
    item.setValue(value);
}

function getStored(current) {
    let result = {
        repair: server.storage.get(storageKeys.repair)
    }
    return result;
}

function getValues(objects) {
    let result = {
        flag: tryGetNumber(objects.flag, 0),
        time: tryGetNumber(objects.time, 0),
        repair: tryGetNumber(objects.repair, 0)
    }
    return result;
}

function tryGetNumber(item, defaultValue) {
    let result = defaultValue;
    try {
        let itemValue = item.getValue();
        if (itemValue !== null) {
            if (isFinite(itemValue.value)) {
                result = Number(itemValue.value);
            }
        }
    }
    catch (err) { }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        flag: dev.item(targetNames.flag),
        time: dev.item(targetNames.time),
        repair: dev.item(targetNames.repair)
    }
    return result;
}