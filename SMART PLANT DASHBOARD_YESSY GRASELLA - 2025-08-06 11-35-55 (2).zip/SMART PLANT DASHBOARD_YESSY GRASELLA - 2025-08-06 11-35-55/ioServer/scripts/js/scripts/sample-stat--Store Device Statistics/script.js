// *****************************************************************************
// Script: Store Device Statistics
// Trigger: Periodically 1000ms 
// The script is used for creation data for Reports module
// *****************************************************************************


// Record template for inserting into database
const recordTemplate = { 
    Timestamp: new Date().toISOString(),    // [datetime2](7) NOT NULL,
    DeviceId: '',    // [DeviceId] [varchar](16) NOT NULL,
    ItemAlias: '@commonGeneric', // [nvarchar](64) NOT NULL,
    State:  false // [bit] NOT NULL,
}

//name of table in the database
const deviceStatisticsTableName = "DeviceStatistics"


//array of records for inserting into database
let records = []


function prepareGenericCommon(object) {
// resolve object    
    // const object = server.object(sourceId, alias)
    const oc = object.getConfig()

// check previous record
    const storedRecord = server.storage.get(oc.id)
    let initialRecord = ! typeof storedRecord == 'object'

    if (storedRecord?.State === undefined) {initialRecord = true}

// get generic parameters
    const generic = object.item('@generic').getValue()
    const genericWarning = object.item('@genericWarning').getValue()

// create a record    
    let myRecord = {...recordTemplate}
    myRecord.DeviceId  = oc.id
    // myRecord.DeviceAlias  = oc.alias
    myRecord.State = Boolean(generic.value | genericWarning.value)

    if (initialRecord) {
        // server.console.log(`initialRecord: ${oc.alias}`)
        myRecord.Timestamp = (Date.parse(generic.timestamp) < Date.parse(genericWarning.timestamp)) ? generic.timestamp : genericWarning.timestamp
        storeRecord(myRecord)
        records.push(myRecord)
    }
    else {
        if (storedRecord.State ^ myRecord.State) {
            myRecord.Timestamp = (Date.parse(generic.timestamp) > Date.parse(genericWarning.timestamp)) ? generic.timestamp : genericWarning.timestamp
            storeRecord (myRecord)
            records.push(myRecord)
        }
    }
}

function makeRecords () {
  // printObject(records)
    const recordId = server.db.insert(deviceStatisticsTableName, records);
    records = []
    server.storage.set('db', recordId)
}

function storeRecord (record) {
    server.storage.set(record.DeviceId, record)
}


function main() {
// get a list of all devices in server
// server.storage.clear()
    let objects = server.objects()

// prepare generic common for all devices
    objects.forEach(o => {
        prepareGenericCommon(o)
    })

// make records into database
    if (records.length > 0) makeRecords()
}
