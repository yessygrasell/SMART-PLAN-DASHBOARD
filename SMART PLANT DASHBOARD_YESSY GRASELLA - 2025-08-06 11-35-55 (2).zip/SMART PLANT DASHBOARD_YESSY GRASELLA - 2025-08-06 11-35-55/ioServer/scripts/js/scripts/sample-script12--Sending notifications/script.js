// *****************************************************************************
// Script: Sending notifications
// Trigger: Periodically 1000ms
// This script is designed to send a notification when conditions are met
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    floatIn: 'floatToNotify',
    discreteIn: 'bitToNotify'
}

// fill out the mailing list
// example: ['TestGroupChat', 'TestEmail']
const recipientList = [];

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_notification_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    if (stored !== null) {
        let currentCond = false;
        let storedCond = false;
        // handle current
        if (current.discreteIn === 1 && current.floatIn > 10) {
            currentCond = true;
        }

        // handle stored
        let floatCond = (stored.prevFloat > 10);
        let discreteCond = (stored.prevDiscrete === 1);

        if ((floatCond === 0 && discreteCond === 0) || (floatCond ^ discreteCond)) {
            storedCond = true;
        }

        if (currentCond && storedCond) {
            for (let i = 0; i < recipientList.length; i++) {
                server.notifications.send(recipientList[i], 'subject', 'message text');
            }
        }
    }
    storeValues(current);
}

function storeValues(current) {
    let storedValue = {
        prevFloat: current.floatIn,
        prevDiscrete: current.discreteIn
    }
    server.storage.set(storageKeys.snapshot, storedValue);
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        floatIn: tryGetNumber(objects.floatIn),
        discreteIn: tryGetNumber(objects.discreteIn)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}


function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        floatIn: dev.item(targetNames.floatIn),
        discreteIn: dev.item(targetNames.discreteIn)
    }
    return result;
}