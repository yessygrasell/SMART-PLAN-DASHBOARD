// *****************************************************************************
// Script: 	Energy efficiency result/costs
// Trigger: Periodically 1000ms
// This script is designed to calculate the specific value of electricity consumption
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    com: 'com1',
    flow: 'energy',
    rate: 'production1',
    effCurrent: 'efficiencyInstant1',
    effSummury: 'efficiencySummary1'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_efficiency1_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    current = generateData(objects, current);

    let stored = getStored();

    // null -> 1 || -> 0
    if (stored === null && current.com === 1) {
        if (current.com === 1) {
            let startValues = makeStartValues(current);
            storeValues(current, startValues);
        }
        else {
            storeValues(current, null);
        }
    }

    if (stored !== null && stored.prevValues.com === 0) {
        // 0 -> 1
        if (current.com === 1) {
            let startValues = makeStartValues(current);
            makeInstantCalc(objects, current, stored);
            storeValues(current, startValues);
        }
    }

    if (stored !== null && stored.prevValues.com === 1) {
        if (current.com === 1) {
            makeCalculations(objects, current, stored);
            storeValues(current, stored.startValues);
        }
        else {
            makeCalculations(objects, current, stored);
            storeValues(current, null);
        }
    }
}

function makeCalculations(objects, current, stored) {
    makeInstantCalc(objects, current, stored);
    makeFullCalc(objects, current, stored);
}

function makeFullCalc(objects, current, stored) {
    let flowDiff = current.flow - stored.startValues.flow;
    let rateDiff = current.rate - stored.startValues.rate;
    let interval = (current.timestamp.valueOf() - stored.startValues.timestamp.valueOf()) / 1000;
    let resultValue = (rateDiff / flowDiff);
    objects.effSummury.setValue(resultValue);
}

function makeInstantCalc(objects, current, stored) {
    let flowDiff = current.flow - stored.prevValues.flow;
    let rateDiff = current.rate - stored.prevValues.rate;
    let resultValue = rateDiff / flowDiff;
    objects.effInstant.setValue(resultValue);
}

function makeStartValues(current) {
    let result = {
        flow: current.flow,
        rate: current.rate,
        timestamp: current.timestamp
    }
    return result;
}

function storeValues(current, startValues) {
    let storeValue = {
        prevValues: {
            flow: current.flow,
            rate: current.rate,
            com: current.com
        }
    }
    storeValue.startValues = startValues;
    server.storage.set(storageKeys.snapshot, storeValue);
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function generateData(objects, current) {
    if (current.com === 1) {
        let flowValue = current.flow + getRndInteger(5, 10);
        let rateValue = current.rate + getRndInteger(5, 10);
        objects.flow.setValue(flowValue);
        objects.rate.setValue(rateValue);

        current.flow = flowValue;
        current.rate = rateValue;
    }
    return current;
}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function getValues(objects) {
    let result = {
        timestamp: new Date(),
        com: tryGetNumber(objects.com),
        flow: tryGetNumber(objects.flow),
        rate: tryGetNumber(objects.rate)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    try {
        let itemValue = item.getValue();
        if (itemValue !== null) {
            if (isFinite(itemValue.value)) {
                result = Number(itemValue.value);
            }
        }
    }
    catch (err) { }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        com: dev.item(targetNames.com),
        flow: dev.item(targetNames.flow),
        rate: dev.item(targetNames.rate),
        effInstant: dev.item(targetNames.effCurrent),
        effSummury: dev.item(targetNames.effSummury)
    }
    return result;
}
