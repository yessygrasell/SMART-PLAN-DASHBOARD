// *****************************************************************************
// Script: Counting the number of triggers
// Trigger: On data change (virtual_1.repair, virtual_1.saveCounted, virtual_1.signal1)
// This script is designed to count the change of discrete value from 0 to 1, exceeding 
// the limits of the float parameter and record these changes in the database when the signal is fed
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    discreteIn: 'repair',
    floatIn: 'signal1',
    discreteOut: 'discreteCounter',
    floatOut: 'floatCounter',
    trigger: 'saveCounted'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_countTriggers_snapshot`
}

const stateValues = {
    hihi: 2,
    hi: 1,
    normal: 0,
    lo: -1,
    lolo: -2
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    processDiscretes(objects, current, stored);

    current.floatState = processFloat(objects, current, stored);

    storeValues(current, stored);
}

function processFloat(objects, current, stored) {
    let config = objects.floatIn.getConfig().config;
    let currentState = getFloatState(current.floatIn, config.hihi, config.hi, config.lo, config.lolo);
    let condOne = (stored === null && currentState !== 0);
    let condZero = (stored === null) ? true : (stored.floatState === currentState) || (currentState === 0) || (Math.abs(stored.floatState) > Math.abs(currentState));
    let needUpdate = condOne || !condZero;
    if (needUpdate) {
        increaseValue(objects.floatOut, current.floatOut);
    }
    return currentState;
}

function getFloatState(value, hihi, hi, lo, lolo) {
    let result = stateValues.normal;
    // hihi
    if (value >= hihi) {
        result = stateValues.hihi;
    }
    // hi
    if (value >= hi && value < hihi) {
        result = stateValues.hi;
    }
    // lo
    if (value <= lo && value > lolo) {
        result = stateValues.lo;
    }
    // lolo
    if (value <= lolo) {
        result = stateValues.lolo;
    }
    return result;
}

function storeValues(current, stored) {
    if ((stored === null) ||
        (current.discreteIn !== stored.discreteIn) ||
        (current.floatState !== stored.floatState) ||
        (current.trigger !== stored.trigger)) {
        stored = {
            discreteIn: current.discreteIn,
            floatState: current.floatState,
            trigger: current.trigger
        }
        server.storage.set(storageKeys.snapshot, stored);
    }
}

function processDiscretes(objects, current, stored) {
    if ((current.trigger === 1 && stored === null) ||
        (current.trigger === 1 && stored.trigger === 0)) {
        makeRecordToDb(objects, current);
        objects.discreteOut.setValue(0);
        objects.floatOut.setValue(0);
    }


    if (stored !== null) {
        if (current.trigger === 1 && stored.trigger === 1) {
            objects.trigger.setValue(0);
        }

        if (current.discreteIn === 1 && stored.discreteIn === 0) {
            increaseValue(objects.discreteOut, current.discreteOut);
        }
    }
}

function increaseValue(item, prevValue) {
    let result = ++prevValue;
    item.setValue(result);
}

function makeRecordToDb(objects, values) {
    let deviceConfig = objects.device.getConfig();
    let triggerConfig = objects.trigger.getConfig();
    let floatValueConfig = objects.floatIn.getConfig();
    let discreteValueConfig = objects.discreteIn.getConfig();
    let message = `${deviceConfig.alias} report: ${floatValueConfig.alias} exceeded the values ${values.floatOut} times; ${discreteValueConfig.alias} changed state from 0 to 1 ${values.discreteOut} times.`;
    let record = {
        Timestamp: new Date().toISOString(),
        ItemId: triggerConfig.id,
        DeviceId: deviceConfig.id,
        DeviceName: deviceConfig.alias,
        ItemName: triggerConfig.alias,
        Value: values.trigger,
        Type: 'I',
        Message: message,
        LoggingNode: ''
    }
    server.db.insert("Events", [record]);
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        discreteIn: tryGetNumber(objects.discreteIn),
        floatIn: tryGetNumber(objects.floatIn),
        discreteOut: tryGetNumber(objects.discreteOut),
        floatOut: tryGetNumber(objects.floatOut),
        trigger: tryGetNumber(objects.trigger)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    let itemValue = item.getValue();
    if (itemValue !== null) {
        if (isFinite(itemValue.value)) {
            result = Number(itemValue.value);
        }
    }

    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        discreteIn: dev.Item(targetNames.discreteIn),
        floatIn: dev.Item(targetNames.floatIn),
        discreteOut: dev.Item(targetNames.discreteOut),
        floatOut: dev.Item(targetNames.floatOut),
        trigger: dev.Item(targetNames.trigger)
    }
    return result;
}