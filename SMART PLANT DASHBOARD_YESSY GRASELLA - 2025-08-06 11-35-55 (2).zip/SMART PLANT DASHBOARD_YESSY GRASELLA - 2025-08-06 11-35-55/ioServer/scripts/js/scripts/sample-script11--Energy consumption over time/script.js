// *****************************************************************************
// Script: Perfomance result/time
// Trigger: Periodically 1000ms
// This script is designed to calculate the consumption of electricity over 
// a period of time
// *****************************************************************************

const targetNames = {
    source: 'scripts',
    device: 'virtual_1',
    floatIn: 'energy',
    floatOut: 'consumption'
}

const storageKeys = {
    snapshot: `${targetNames.source}_${targetNames.device}_consumption_snapshot`
}

// Entry point, don't delete!
function main() {
    // Your code here
    let objects = getObjects();

    let current = getValues(objects);

    let stored = getStored();

    if (stored !== null) {
        if (isDiffers(current, stored)) {
            let valuesDiff = current.floatIn - stored.prevValue;
            objects.floatOut.setValue(valuesDiff);
            storeValues(current);
        }
    }
    else {
        storeValues(current);
    }
}

function storeValues(current) {
    let stored = {
        prevValue: current.floatIn
    }
    server.storage.set(storageKeys.snapshot, stored);
}

function isDiffers(current, stored) {
    if (current.floatIn !== stored.prevValue) {
        return true;
    }
    return false;
}

function getStored() {
    let result = server.storage.get(storageKeys.snapshot);
    return result;
}

function getValues(objects) {
    let result = {
        timestamp: new Date(),
        floatIn: tryGetNumber(objects.floatIn)
    }
    return result;
}

function tryGetNumber(item) {
    let result = 0;
    try {
        let itemValue = item.getValue();
        if (itemValue !== null) {
            if (isFinite(itemValue.value)) {
                result = Number(itemValue.value);
            }
        }
    }
    catch (err) { }
    return result;
}

function getObjects() {
    let dev = server.object(targetNames.source, targetNames.device);
    let result = {
        device: dev,
        floatIn: dev.item(targetNames.floatIn),
        floatOut: dev.item(targetNames.floatOut)
    }
    return result;
}